package com.lnt.appl.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.lnt.appl.beans.Department;

import com.lnt.appl.services.DeptServiceImpl;


@CrossOrigin(origins="*")
@RestController
@RequestMapping("/dept/")
public class DepartmentController {

	@Autowired
	private DeptServiceImpl deptService;
	
	// http://localhost:8090/dept/departments
	
	@GetMapping("/departments")
	public List<Department> getDeptList()
	{
		System.out.println(" inside controller - calling getDeptList");		
		List<Department> deptList= deptService.getDeptList();
		return deptList;			
	}
	
	//http://localhost:8090/dept/deptnos
	
	@GetMapping("/deptnos")
	public List<Department> getDeptNos()
	{
		System.out.println(" inside controller - calling getDeptNos");		
		List<Department> deptList= deptService.getDeptNos();
		return deptList;			
	}
	
	
}