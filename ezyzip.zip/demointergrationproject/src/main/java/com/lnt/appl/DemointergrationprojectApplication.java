package com.lnt.appl;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemointergrationprojectApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemointergrationprojectApplication.class, args);		
	}
	}
//https://www.pixeltrice.com/how-to-send-email-using-spring-boot-application/