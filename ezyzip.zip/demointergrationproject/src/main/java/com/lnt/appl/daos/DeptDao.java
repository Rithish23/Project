package com.lnt.appl.daos;

import java.util.List;

import com.lnt.appl.beans.Department;


public interface DeptDao {
	public List<Department> getDeptList() ; 	
	public List<Department> getDeptNos() ;

}
