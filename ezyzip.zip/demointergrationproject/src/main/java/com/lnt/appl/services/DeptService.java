package com.lnt.appl.services;

import java.util.List;

import com.lnt.appl.beans.Department;

public interface DeptService {
	public List<Department> getDeptList() ; 	
	public List<Department> getDeptNos() ;
}
