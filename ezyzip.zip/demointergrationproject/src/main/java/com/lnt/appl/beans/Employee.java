package com.lnt.appl.beans;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;


@Entity
@Table(name="EMP_SPRING")
public class Employee {
	
	@Id
	@Column(name="EMP_No")
	private int empNo;

	@Column(name="EMP_Name")
	private String empName;
		
	@Column(name="EMP_SAL")
	private long empSal;
	
	@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"}) // i got error of 
	@ManyToOne(fetch=FetchType.LAZY,cascade={CascadeType.ALL})  
	@JoinColumn(name="DEPT_NO")
	private Department dept;  
	
	
	// if you already have table with records and then u r adding this field , add column manually in a table 
	//	alter table EMP_Spring 	add  DEPT_NO number(2) 
	
	public Department getDept() {
		return dept;
	}

	public void setDept(Department dept) {
		this.dept = dept;
	}

	public Employee() {
		super();
	}

	public Employee(int empNo, String empName, long empSal) {
		super();
		this.empNo = empNo;
		this.empName = empName;
		this.empSal = empSal;
	}

	public int getEmpNo() {
		return empNo;
	}

	public void setEmpNo(int empNo) {
		this.empNo = empNo;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public long getEmpSal() {
		return empSal;
	}

	public void setEmpSal(long empSal) {
		this.empSal = empSal;
	}

	@Override
	public String toString() {
		return "Employee [empNo=" + empNo + ", empName=" + empName + ", empSal=" + empSal + "]";
	}


	
	
}
