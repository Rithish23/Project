package com.lnt.appl.daos;

import java.util.List;

import javax.persistence.EntityManager;

import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Repository;

import com.lnt.appl.beans.Department;
import com.lnt.appl.beans.Employee;
import com.lnt.appl.exception.CustomException;

/*@Component is the most generic Spring annotation.  * 
 * A Java class decorated with @Component is found during classpath scanning 
 * and registered in the context as a Spring bean. ... 
 * @ComponentScan ensures that the classes decorated with
 *  @Component are found and registered as Spring beans.
 */
/*
 * @Component:
 * 		@Repository: It represents DAO Classes.
 * 		@Service:It represents Service classes.
 * 		@Cntroller: It represents Controller classes of Spring MVC
 * 		@RestController: It represents REST layer of Web Services.
 */
@Repository("empDao")
public class EmpDaoImpl implements EmpDao {

	@Autowired
	DeptDao deptDao;

	@PersistenceContext
	private EntityManager entityManager;

	public List<Employee> getEmpList() {
		// String sql = "SELECT e FROM empRec e";
		String sql = "SELECT e FROM Employee e"; // -- just to reduce display
		Query qry = entityManager.createQuery(sql);
		List<Employee> empList = qry.getResultList();
		return empList;
	}

	public Employee getEmpById(int empno) throws CustomException {
		
		Employee emp = entityManager.find(Employee.class, empno);

		return emp;

		// String sql = "SELECT e FROM empRec e where e.empno=?";
		// Query qry = entityManager.createQuery(sql);
		// List<Employee> empList = qry.getResultList();
		// return empList;

	}

	@Transactional
	public Employee saveEmployee(Employee emp, int deptno) {

		Department dept = entityManager.find(Department.class, deptno);

		if (dept == null) {

		} else {

			emp.setDept(dept);
			entityManager.persist(emp);
		}
		return emp;
	}

	@Transactional
	public Employee saveEmp(Employee emp) {
		
			entityManager.persist(emp);
		
		return emp;
	}
	
	@Override
	@Transactional
	public boolean updateEmp(int empId, long empSal) {

		 Employee employee =entityManager.find(Employee.class,empId);
	        employee.setEmpSal(empSal);
	        entityManager.merge(employee);
	        entityManager.close();
	        return true;		
	}
}
