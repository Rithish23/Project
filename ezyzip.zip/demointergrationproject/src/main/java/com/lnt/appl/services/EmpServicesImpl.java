
package com.lnt.appl.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lnt.appl.beans.Employee;
import com.lnt.appl.daos.EmpDao;
import com.lnt.appl.exception.CustomException;


@Service("empService")  
public class EmpServicesImpl implements EmpServices {
	
	@Autowired  // By Type injection.
	private EmpDao empDao;
	
	public void setEmpDao(EmpDao empDao) {
		this.empDao = empDao;
	}
	
	public int saveEmployee(Employee emp,int deptno) {
		empDao.saveEmployee(emp,deptno);
		return 0;
	}

	public List<Employee> getEmpList(){
		return empDao.getEmpList();
	}

	public Employee getEmpById(int empno)	 throws CustomException{
		
		return empDao.getEmpById(empno);
	}

	@Override
	public Employee saveEmp(Employee emp) {
		
			return empDao.saveEmp(emp);
	}

	@Override
	public boolean updateEmp(int empId, long empSal) {
		
		return empDao.updateEmp(empId, empSal);
	}

	
}
