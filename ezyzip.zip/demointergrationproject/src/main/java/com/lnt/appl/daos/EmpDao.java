package com.lnt.appl.daos;


import java.util.List;

import com.lnt.appl.beans.Employee;
import com.lnt.appl.exception.CustomException;
public interface EmpDao
{
	public List<Employee> getEmpList() ; 	
	public Employee getEmpById(int empno) throws CustomException ;
	public Employee saveEmp(Employee emp);
	//f key with dept
	public Employee saveEmployee(Employee emp,int deptno) ;
	public boolean updateEmp(int empId, long empSal);
	
}
