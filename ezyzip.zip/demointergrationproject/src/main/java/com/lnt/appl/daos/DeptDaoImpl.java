package com.lnt.appl.daos;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.lnt.appl.beans.Department;



@Repository("deptDao")
public class DeptDaoImpl implements DeptDao {
	
	@PersistenceContext
	private EntityManager entityManager;
	

	@Override
	public List<Department> getDeptList() {
		
				String sql = "SELECT d FROM Department d"; //-- just to reduce display
				Query qry = entityManager.createQuery(sql);		
				List<Department> deptList = qry.getResultList();
				return deptList;	
	}

	@Override
	public List<Department> getDeptNos() {
		
				String sql = "SELECT d.deptNo FROM Department d"; //-- just to reduce display
				Query qry = entityManager.createQuery(sql);		
				List<Department> deptList = qry.getResultList();
				return deptList;	
	}
}
