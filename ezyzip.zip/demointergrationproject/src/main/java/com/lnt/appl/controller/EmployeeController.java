package com.lnt.appl.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.lnt.appl.beans.Employee;
import com.lnt.appl.exception.CustomException;
import com.lnt.appl.services.EmpServicesImpl;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/emp")
public class EmployeeController {

	@Autowired
	private EmpServicesImpl employeeService;

	// http://localhost:8090/emp/employees

	@GetMapping("/employees")
	public List<Employee> getEmpList() {
		System.out.println(" inside controller - calling getEmpList");
		List<Employee> empList = employeeService.getEmpList();
		return empList;
	}

	// http://localhost:8090/emp/employee/101

	@GetMapping("/employee/{id}")
	public Employee getEmpById(@PathVariable(value = "id") int empno) throws CustomException {
		Employee e = null;

		e = employeeService.getEmpById(empno);

		System.out.println(" controller " + e);

		return e;
	}

	/*
	 * @GetMapping("/employee/{id}") public Status getEmpById(@PathVariable(value =
	 * "id") int empno){ Status status = new Status(); Employee e =
	 * employeeService.getEmpById(empno); status.setStatus(StatusType.SUCCESS);
	 * status.setMessage("Registration successful!"); return status; }
	 */

	
	  //http://localhost:8090/emp/addnewemp
	  
	  @PostMapping("/addnewemp") public void saveEmployee(@RequestBody Employee emp) 
	  { 
		  employeeService.saveEmp(emp);
	  
	  }
	 

	// http://localhost:8090/emp/addemp/10 // along with fk deptno
	@PostMapping(value = "/addemp/{deptid}")
	public void saveEmp(@PathVariable(value = "deptid") int deptid, @RequestBody Employee emp) {

		System.out.println("inside controller " + emp);
		employeeService.saveEmployee(emp, deptid);

	}

	/*
	 * { "empNo": 106, "empName": "bbbb", "empSal": 99999.9, "dept" : { "deptNo":20
	 * } }
	 */
	//http://localhost:8090/emp/updateemp/101/70000
	@PutMapping(value = "/updateemp/{empId}/{empSal}")
	public void updateEmp(@PathVariable(value = "empId") int empId, @PathVariable(value = "empSal") int empSal) {

		System.out.println("inside controller " + empId + " " + empSal);
		employeeService.updateEmp(empId, empSal);
	}

}
