package com.lnt.appl;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.web.bind.annotation.PathVariable;

import com.lnt.appl.beans.Employee;
import com.lnt.appl.daos.EmpDaoImpl;
import com.lnt.appl.exception.CustomException;
import com.lnt.appl.services.EmpServicesImpl;

@SpringBootTest
class DemointergrationprojectApplicationTests {

	private EmpDaoImpl daoService=new EmpDaoImpl();
	
	@Test
	void testSearch() throws CustomException {
		
			Employee testObj= new Employee(101,"Jay",99999);
			Employee e = daoService.getEmpById(102);
			System.out.println("test" +e);
		}
}
