package com.lnt.appl.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lnt.appl.beans.Department;
import com.lnt.appl.daos.DeptDao;


@Service
public class DeptServiceImpl implements DeptService{

	@Autowired  // By Type injection.
	private DeptDao deptDao;
	
	
	public DeptDao getDeptDao() {
		return deptDao;
	}


	public void setDeptDao(DeptDao deptDao) {
		this.deptDao = deptDao;
	}

	@Override
	public List<Department> getDeptList() {
		return deptDao.getDeptList();
	
	}


	@Override
	public List<Department> getDeptNos() {
		return deptDao.getDeptNos();
	}
}

	
