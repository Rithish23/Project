package com.lti.AIRLINERESERVATIONSYSTEM.services;

import java.util.List;
import com.lti.AIRLINERESERVATIONSYSTEM.beans.Passengers;

public interface PassengerService {
	
	public abstract String addPassengers(Passengers p);
	
	public abstract Passengers findPassengerById(String passId);
	
	public abstract List<Passengers> listAllPassengers();
	
	public String updateFirstName(String passId,String fName);

	public abstract String deleteById(String passId);
}
