package com.lti.AIRLINERESERVATIONSYSTEM.services;

import java.util.List;

import com.lti.AIRLINERESERVATIONSYSTEM.beans.City;

public interface CityService {
	
	public abstract String addCity(City c);

	public abstract City findCityById(String passId);
  
	public abstract List<City> listAllPassengers();

}
