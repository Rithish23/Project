package com.lti.AIRLINERESERVATIONSYSTEM.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.lti.AIRLINERESERVATIONSYSTEM.beans.City;

@Repository
public class CityDaoImpl implements CityDao{

	@PersistenceContext
	EntityManager em;
	  
	
	@Override
	@Transactional
	public String addCity(City c) {
		em.persist(c);
		return c.getCityId();
	}

	@Override
	public City findCityById(String passId) {
		
		return null;
	}

	@Override
	public List<City> listAllPassengers() {
		
		return null;
	}

}
