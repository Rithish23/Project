package com.lti.AIRLINERESERVATIONSYSTEM.services;

import java.util.List;

import com.lti.AIRLINERESERVATIONSYSTEM.beans.City;

public class CityServiceImpl implements CityService{

	@Override
	public String addCity(City c) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public City findCityById(String passId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<City> listAllPassengers() {
		// TODO Auto-generated method stub
		return null;
	}

	
	
}
