package com.lti.AIRLINERESERVATIONSYSTEM.dao;

import java.util.List;

import com.lti.AIRLINERESERVATIONSYSTEM.beans.City;

public interface CityDao {
	
	public abstract String addCity(City c);

	public abstract City findCityById(String passId);
  
	public abstract List<City> listAllPassengers();

}
