package com.lti.AIRLINERESERVATIONSYSTEM.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lti.AIRLINERESERVATIONSYSTEM.beans.Transaction;
import com.lti.AIRLINERESERVATIONSYSTEM.dao.TransactionDao;

@Service("TransactionService")
public class TransactionServiceImpl implements TransactionService{
	
	@Autowired
	TransactionDao dao;
	
	public TransactionDao getDao() {
		return dao;
	}

	public void setDao(TransactionDao dao) {
		this.dao = dao;
	}



	@Override
	public int addTransaction(Transaction t) {
			int TrId=dao.addTransaction(t);
			return TrId;
		
	}

	@Override
	public List<Transaction> listAllTransaction() {
		System.out.println("service layer");
		List<Transaction>TrasnList = dao.listAllTransaction();
		return TrasnList;
	}

	@Override
	public Transaction findTransactionId(int Trans_id) {
		return dao.findTransactionId(Trans_id);
		
	}


	@Override
	public void deleteById(int TrId) {
		dao.deleteById(TrId);
			
	}

	/*
	 * @Override public String addTransactionFk(Transaction t, String passId, String
	 * flightNo, String seatNo, int cityId) {
	 * 
	 * dao.addTransactionFk(t, passId, flightNo, seatNo, cityId); return "0" ; }
	 */




}