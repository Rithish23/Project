package com.lti.AIRLINERESERVATIONSYSTEM.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;
import org.springframework.stereotype.Repository;

import com.lti.AIRLINERESERVATIONSYSTEM.beans.City;
import com.lti.AIRLINERESERVATIONSYSTEM.beans.Flight;
import com.lti.AIRLINERESERVATIONSYSTEM.beans.Passengers;
import com.lti.AIRLINERESERVATIONSYSTEM.beans.Seat;
import com.lti.AIRLINERESERVATIONSYSTEM.beans.Transaction;

@Repository
public class TransactionDaoImpl implements TransactionDao{

	@PersistenceContext
	private EntityManager em;
	
	
	@Override
	@Transactional
	public int addTransaction(Transaction t) {
		em.persist(t);
		return t.getTrId();
		
	}


	@Override
	public List<Transaction> listAllTransaction() {
		
		String sql= "Select t From Transaction t";
		Query qry=em.createQuery(sql);
		List<Transaction>TransList=qry.getResultList();
		System.out.println("on db server"+TransList);
		return TransList;
	}


	@Override
	public Transaction findTransactionId(int Trans_id) {
		System.out.println("*Found*");
		Transaction a=em.find(Transaction.class,Trans_id);
		return a;
	}

	/*
	 * @Override
	 * 
	 * @Transactional public int UpdatecityId(int TrId, int cityId) { Transaction
	 * trans1 = em.find(Transaction.class, TrId); trans1.setTfair(cityId);
	 * em.merge(trans1); return trans1.getCityId(); }
	 */


	@Override
	@Transactional
	public void deleteById(int TrId) {
		Transaction user=em.find(Transaction.class, TrId);
		em.remove(user);
		
	}


	/*
	 * @Override
	 * 
	 * @Transactional public Transaction addTransactionFk(Transaction t, String
	 * passId, String flightNo, String seatNo, int cityId) { Passengers p=
	 * em.find(Passengers.class, passId); Flight f=em.find(Flight.class,flightNo);
	 * Seat s= em.find(Seat.class,seatNo); City c=em.find(City.class,cityId);
	 * 
	 * if(p==null || f==null || s==null || c==null) {
	 * 
	 * System.out.println(); }else {
	 * 
	 * t.setPassangerId(p); t.setFlightNo(f); t.setSeatNo(s); t.setCityId(c);
	 * em.persist(t); }
	 * 
	 * return t; }
	 */

}