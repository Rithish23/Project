package com.lti.AIRLINERESERVATIONSYSTEM.dao;

import java.util.List;

import com.lti.AIRLINERESERVATIONSYSTEM.beans.Transaction;


public interface TransactionDao {

	public abstract int addTransaction(Transaction t);
	public abstract List<Transaction> listAllTransaction();
	public abstract Transaction findTransactionId(int Trans_id);
	public abstract void  deleteById(int TrId);
	/*
	 * public abstract Transaction addTransactionFk(Transaction t, String passId,
	 * String flightNo, String seatNo, int cityId );
	 */
	
	

}