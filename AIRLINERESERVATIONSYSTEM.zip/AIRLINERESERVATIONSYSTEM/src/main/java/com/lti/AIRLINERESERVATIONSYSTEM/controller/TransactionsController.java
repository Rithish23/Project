package com.lti.AIRLINERESERVATIONSYSTEM.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.lti.AIRLINERESERVATIONSYSTEM.beans.Transaction;
import com.lti.AIRLINERESERVATIONSYSTEM.services.TransactionServiceImpl;

@CrossOrigin(origins= "*")
@RestController
@RequestMapping("/tra")
public class TransactionsController {

	
	
	@Autowired
	TransactionServiceImpl TransactionService;

	//http://localhost:8090/tra/t1
	@GetMapping("/t1")
	public List<Transaction> listAllTransaction()
	{
		List<Transaction>traList= TransactionService.listAllTransaction();
		return traList;
		
	}
	
	//http://localhost:8090/tra/findId/111
	@GetMapping("/findId/{id}")
	public Transaction findTransactionId(@PathVariable(value = "id")int Trans_id)
	{ 
		
		Transaction a= null;
		a= TransactionService.findTransactionId(Trans_id);
		return a;
	}
	
	
	/*
	 * // //http://localhost:8090/tra/addTransaction/P03/6E316/A2/1002
	 * // @PostMapping(value=
	 * "/addTransaction/{passId}/{flightNo}/{seatNo}/{cityId}") // public void
	 * addTransactionFk(@PathVariable(value="passId")String passId
	 * ,@PathVariable(value="flightNo") String flightNo,
	 * // @PathVariable(value="seatNo") String seatNo,@PathVariable(value="cityId")
	 * int cityId, @RequestBody Transaction t ) // { // System.out.println(t); // //
	 * TransactionService.addTransactionFk(t, passId, flightNo, seatNo, cityId); //
	 * // }
	 */	
}