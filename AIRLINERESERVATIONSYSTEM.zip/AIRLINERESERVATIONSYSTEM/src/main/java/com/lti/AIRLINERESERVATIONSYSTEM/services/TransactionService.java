package com.lti.AIRLINERESERVATIONSYSTEM.services;

import java.util.List;

import org.springframework.stereotype.Service;
import com.lti.AIRLINERESERVATIONSYSTEM.beans.Transaction;

@Service("TransactionService")
public interface TransactionService {
	
	public abstract int addTransaction(Transaction t);
	public abstract List<Transaction> listAllTransaction();
	public abstract Transaction findTransactionId(int Trans_id);
	public abstract void  deleteById(int TrId);
	/*
	 * public abstract String addTransactionFk(Transaction t, String passId, String
	 * flightNo, String seatNo, int cityId );
	 */
}